---
template: home.html
title: Material for MkDocs
---

Welcome to Material for MkDocs.
